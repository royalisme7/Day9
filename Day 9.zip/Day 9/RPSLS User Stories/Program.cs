﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPSLS_User_Stories
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
// I want to make good, consistent commits.  
int inheritance;