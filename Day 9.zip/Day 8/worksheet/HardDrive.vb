﻿Public Class HardDrive

End Class
Public List<Applications> ApplicationsInHardDrive;
