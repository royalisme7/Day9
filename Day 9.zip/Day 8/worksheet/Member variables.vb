﻿Public Class Member_variables

End Class
Public Manufacturer;
Public Double EffectiveMemory;